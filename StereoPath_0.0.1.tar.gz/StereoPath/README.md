# StereoPath

## Installation

StereoPath R package can be easily installed from Github using devtools:  

```
devtools::install_github("STOmics/StereoPath")
```
